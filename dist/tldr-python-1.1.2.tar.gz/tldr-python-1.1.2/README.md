# tldr-python

Python wrapper for the TLDR text summarization and analysis API available on [RapidAPI](https://rapidapi.com/AmolMavuduru/api/tldr-text-analysis).

## Installation

```
pip install tldr-python
```

## Introduction

tldr-python is a wrapper over the TLDR text summarization and analysis API. To use this API, create an account on [RapidAPI](https://rapidapi.com/) and [subscribe to the API](https://rapidapi.com/AmolMavuduru/api/tldr-text-analysis).

