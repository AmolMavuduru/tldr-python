# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['tldr_python']

package_data = \
{'': ['*']}

install_requires = \
['requests>=2.5,<3.0']

setup_kwargs = {
    'name': 'tldr-python',
    'version': '1.1.4',
    'description': 'Python wrapper for the TLDR text summarization and analysis API.',
    'long_description': '# tldr-python\n\nPython wrapper for the TLDR text summarization and analysis API available on [RapidAPI](https://rapidapi.com/AmolMavuduru/api/tldr-text-analysis).\n\n## Installation\n\n```\npip install tldr-python\n```\n\n## Introduction\n\ntldr-python is a wrapper over the TLDR text summarization and analysis API. To use this API, create an account on [RapidAPI](https://rapidapi.com/) and [subscribe to the API](https://rapidapi.com/AmolMavuduru/api/tldr-text-analysis).\n\n',
    'author': 'Amol Mavuduru',
    'author_email': 'amolmavuduru@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
